const spawnClient = require("./client-spawner.js");
const appConfig = require("./config.json");

spawnClient(appConfig);
